﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Genetic_algorithm_assignment
{
    static class PopulationExtensions
    {
        //public static Population GenericAlgorithm(this Population population, int iterations, bool useElitism = false)
        //{
        //    return population.Evolve(useElitism);
        //}
    }
}
