﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Genetic_algorithm_assignment
{
    enum SelectionMethod
    {
        ROULETTE,
        RANK,
        TOURNAMENT
    }
}
