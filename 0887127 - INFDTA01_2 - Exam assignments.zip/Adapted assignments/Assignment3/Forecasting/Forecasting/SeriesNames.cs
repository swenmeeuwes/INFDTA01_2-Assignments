﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Forecasting
{
    enum SeriesNames
    {
        Data,
        Ses,
        Des
    }
}
